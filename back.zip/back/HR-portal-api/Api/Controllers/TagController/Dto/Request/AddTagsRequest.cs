﻿namespace HR_portal_api.Controllers.TagController.Dto;

public class AddTagsRequest
{
    public long[] TagIdList { get; set; }
}