﻿namespace HR_portal_api.Controllers.TagController.Dto;

public class CreateTagRequest
{
    public string? Name { get; set; }

    public string? Description { get; set; }
}