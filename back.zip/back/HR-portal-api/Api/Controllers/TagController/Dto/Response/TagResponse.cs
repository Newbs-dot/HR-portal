﻿namespace HR_portal_api.Controllers.TagController.Dto.Response;

public class TagResponse
{
    public long Id { get; set; }
    
    public string Name { get; set; }

    public string Description { get; set; }
}