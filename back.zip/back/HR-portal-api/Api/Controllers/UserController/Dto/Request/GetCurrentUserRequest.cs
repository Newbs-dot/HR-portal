﻿using Dal.Models;

namespace HR_portal_api.Controllers.UserController.Dto.Request;

public class GetCurrentUserRequest : TokenModel
{
}