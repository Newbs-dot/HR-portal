﻿using Dal.Models;

namespace HR_portal_api.Controllers.VacancyController.Dto.Request;

public class RespondToVacancyRequest : TokenModel
{
}