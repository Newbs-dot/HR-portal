﻿namespace Dal.Constants;

public class RoleConstants
{
    public const string User = nameof(User);
    
    public const string DepartmentsHead = nameof(DepartmentsHead);
    
    public const string Administrator = nameof(Administrator);
}