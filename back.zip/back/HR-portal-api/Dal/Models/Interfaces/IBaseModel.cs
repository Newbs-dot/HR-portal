﻿namespace Dal.Models.Interfaces;

public interface IBaseModel
{
    public long Id { get; set; }
}