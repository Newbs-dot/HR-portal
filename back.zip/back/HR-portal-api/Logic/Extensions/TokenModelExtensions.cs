﻿namespace Logic.Extensions;

public class TokenModelExtensions
{
    
}