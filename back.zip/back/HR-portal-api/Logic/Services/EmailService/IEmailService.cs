﻿namespace Logic.Services.EmailService;

public interface IEmailService
{
    
}