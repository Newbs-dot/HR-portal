﻿namespace Logic.Settings;

public class EmailSettings
{
    public const string EmailData = nameof(EmailData);

    public string Email { get; set; }

    public string Password { get; set; }
}